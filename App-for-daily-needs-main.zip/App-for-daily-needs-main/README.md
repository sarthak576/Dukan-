# App-for-daily-needs
A simple app written in HTML and got into exe file. with this app you can easily have your important websites opened into the file window!
